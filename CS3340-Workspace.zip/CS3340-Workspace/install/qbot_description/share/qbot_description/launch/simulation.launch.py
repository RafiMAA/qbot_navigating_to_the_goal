import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess, RegisterEventHandler, TimerAction, SetEnvironmentVariable
from launch.event_handlers import OnProcessStart
from launch_ros.actions import Node

def generate_launch_description():
    # 1. Define package paths
    pkg_dir = get_package_share_directory('qbot_description')
    urdf_file = os.path.join(pkg_dir, 'urdf', 'qbot.urdf')
    world_file = os.path.join(pkg_dir, 'sdf', 'qbot_world.sdf')
    rviz_config = os.path.join(pkg_dir, 'rviz', 'qbot.rviz')

    # 2. Read URDF file
    with open(urdf_file, 'r') as infp:
        robot_desc = infp.read()

    # 3. Set Environment Variables for Gazebo Harmonic 
    set_gz_plugin_path = SetEnvironmentVariable(
        name='GZ_SIM_SYSTEM_PLUGIN_PATH',
        value=os.environ.get('LD_LIBRARY_PATH', '')
    )

    # 4. Start Gazebo
    gazebo = ExecuteProcess(
        cmd=['gz', 'sim','-r', world_file],
        output='screen'
    )

    # 5. Robot State Publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_desc,
            'use_sim_time': True
        }]
    )

    # 6. RViz2
    rviz2 = Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', rviz_config],
        parameters=[{'use_sim_time': True}],
        output='screen'
    )

    # 7. ROS-Gazebo Bridge (FIXED: Proper ROS 2 Jazzy remapping)
    gz_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
            '/lidar@sensor_msgs/msg/LaserScan[gz.msgs.LaserScan'
        ],
        remappings=[
            ('/lidar', '/scan')
        ],
        output='screen'
    )

    # 8. Controller Spawners
    joint_state_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster'],
    )
    
    diff_drive_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['diff_drive_controller'],
    )

    # 9. Delay Controllers until Robot State Publisher is running
    delay_controllers = RegisterEventHandler(
        event_handler=OnProcessStart(
            target_action=robot_state_publisher,
            on_start=[
                TimerAction(
                    period=3.0,
                    actions=[joint_state_broadcaster_spawner]
                ),
                TimerAction(
                    period=12.0,
                    actions=[diff_drive_controller_spawner]
                )
            ]
        )
    )

    # Return the complete LaunchDescription
    return LaunchDescription([
        set_gz_plugin_path,
        gazebo,
        robot_state_publisher,
        rviz2,
        gz_bridge,
        delay_controllers
    ])