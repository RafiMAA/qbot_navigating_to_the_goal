#lab_06_sim_launch.py

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node


def generate_launch_description():

    qbot_share   = get_package_share_directory('qbot_description')
    lab_06_share = get_package_share_directory('lab_06')

    simulation_launch_path = os.path.join(qbot_share, 'launch', 'simulation.launch.py')
    slam_config_path       = os.path.join(lab_06_share, 'config', 'slam_toolbox_params.yaml')

    simulation = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(simulation_launch_path),
    )

    slam_pose_node = Node(
        package='lab_06',
        executable='slam_pose_publisher',
        name='slam_pose_publisher',
        parameters=[{'use_sim_time': True}],
        output='screen',
    )

    navigation_server = Node(
        package='lab_06',
        executable='navigation_server',
        name='navigation_server',
        parameters=[{'use_sim_time': True}],
        output='screen',
    )

    qbot_controller = Node(
        package='lab_06',
        executable='qbot_controller',
        name='qbot_controller',
        remappings=[('/cmd_vel', '/cmd_vel_raw')],
        parameters=[{'use_sim_time': True}],
        output='screen',
    )

    slam_node = Node(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',
        name='slam_toolbox',
        output='screen',
        parameters=[
            slam_config_path,
            {'use_sim_time': True, 'mode': 'mapping'}
        ],
    )

    lifecycle_manager = TimerAction(
        period=10.0,
        actions=[
            Node(
                package='nav2_lifecycle_manager',
                executable='lifecycle_manager',
                name='lifecycle_manager_slam',
                output='screen',
                parameters=[{
                    'use_sim_time': True,
                    'autostart': True,
                    'node_names': ['slam_toolbox'],
                    'bond_timeout': 0.0,
                }],
            )
        ]
    )

    # REMOVED AMCL NODES FROM THIS LIST
    return LaunchDescription([
        simulation,
        slam_node,
        lifecycle_manager,
        navigation_server,
        qbot_controller,
        slam_pose_node,
    ])